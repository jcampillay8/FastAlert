import flet as ft
import httpx
import asyncio

# --- CONFIGURACIÓN ---
# Asegúrate de que esta IP sea accesible desde tu celular (mismo Wi-Fi)
API_BASE_URL = "http://192.168.100.32:8000/alarma/activar"

async def main(page: ft.Page):
    page.title = "FastAlert"
    page.theme_mode = ft.ThemeMode.DARK
    page.padding = 20
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    state = {"phone": None}

    # Intentar recuperar el teléfono al iniciar
    try:
        val = page.client_storage.get("user_phone")
        if val:
            state["phone"] = val
    except:
        pass

    # --- LÓGICA DE ALERTA ---
    async def send_panic_alert():
        phone = state["phone"]
        
        # Feedback visual de carga
        panic_button.disabled = True
        panic_button.opacity = 0.5
        page.update()

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                response = await client.post(
                    API_BASE_URL, 
                    json={"telefono": phone}
                )
                
                if response.status_code == 200:
                    msg = "✅ ALERTA ENVIADA"
                    color = ft.Colors.GREEN_700
                else:
                    msg = f"❌ Error API: {response.status_code}"
                    color = ft.Colors.RED_700
        except httpx.ConnectError:
            msg = "🚨 No se pudo conectar al servidor (IP incorrecta o red distinta)"
            color = ft.Colors.ORANGE_900
        except Exception as e:
            msg = f"🚨 Error: {str(e)}"
            color = ft.Colors.RED_900
        
        # Mostrar SnackBar con el nuevo método de Flet 0.84+
        page.open(ft.SnackBar(ft.Text(msg), bgcolor=color))
        
        panic_button.disabled = False
        panic_button.opacity = 1.0
        page.update()

    # --- DIÁLOGOS ---
    async def handle_confirm(e):
        page.close(confirm_dialog)
        page.update()
        await send_panic_alert()

    async def close_dlg(e):
        page.close(confirm_dialog)
        page.update()

    confirm_dialog = ft.AlertDialog(
        modal=True,
        title=ft.Text("⚠️ CONFIRMAR"),
        content=ft.Text("¿Activar la alerta ahora?"),
        actions=[
            ft.TextButton("SÍ, ACTIVAR", on_click=handle_confirm, style=ft.ButtonStyle(color=ft.Colors.RED)),
            ft.TextButton("NO", on_click=close_dlg),
        ],
    )

    async def open_confirmation(e):
        page.open(confirm_dialog)
        page.update()

    # --- COMPONENTES ---
    panic_button = ft.Container(
        content=ft.Column(
            [
                ft.Icon(ft.Icons.GPP_BAD, size=80, color=ft.Colors.WHITE),
                ft.Text("ACTIVAR\nALERTA", size=30, weight="bold", text_align="center"),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=280,
        height=280,
        bgcolor=ft.Colors.RED_700,
        shape=ft.BoxShape.CIRCLE,
        on_click=open_confirmation,
    )

    phone_input = ft.TextField(
        label="Tu número de teléfono",
        hint_text="569XXXXXXXX",
        width=300,
        keyboard_type=ft.KeyboardType.PHONE
    )

    async def save_config(e):
        if phone_input.value and len(phone_input.value) >= 9:
            state["phone"] = phone_input.value
            try:
                page.client_storage.set("user_phone", phone_input.value)
            except: pass
            await show_main_view()
        else:
            page.open(ft.SnackBar(ft.Text("Ingresa un número válido")))
            page.update()

    async def show_main_view():
        page.controls.clear()
        page.add(
            ft.Text("SISTEMA DE SEGURIDAD", size=14, weight="bold", opacity=0.6),
            ft.Divider(height=40, color=ft.Colors.TRANSPARENT),
            panic_button,
            ft.Divider(height=60, color=ft.Colors.TRANSPARENT),
            ft.Text(f"📞 {state['phone']}", size=16, opacity=0.8),
            ft.TextButton("Cambiar número", on_click=reset_config),
        )
        page.update()

    async def reset_config(e):
        state["phone"] = None
        try: page.client_storage.clear()
        except: pass
        page.controls.clear()
        page.add(onboarding_view)
        page.update()

    onboarding_view = ft.Column(
        [
            ft.Icon(ft.Icons.SECURITY, size=100, color=ft.Colors.BLUE_400),
            ft.Text("Configuración", size=24, weight="bold"),
            phone_input,
            ft.FilledButton("GUARDAR", on_click=save_config, width=300),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )

    if state["phone"]:
        await show_main_view()
    else:
        page.add(onboarding_view)

if __name__ == "__main__":
    ft.app(main)